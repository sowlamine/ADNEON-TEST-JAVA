/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adneon.partition;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import com.adneon.partition.PartitionService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.collections4.ListUtils;

/**
 *
 * @author sow
 */
public class PartitionTest {

    public PartitionTest() {
    }
    //Creation de mon object
    PartitionService prt = new PartitionService();
    //Affichage debut des tests 

    @Test
    public void init() {
        System.out.println("Begin Unit Test Partition , ADNEON-TEST-JAVA ...");

    }
    //Test de mon object 

    @Test
    public void initOK() {
        System.out.println("Begin Unit Test Init my object...");
        assertNotNull(prt);
    }
    //Si mon object , maintenant tester est qu'il fait le travail que je lui demande 

    @Test
    public void testPartition() {
        System.out.println("Begin Test Partition ...");
        int nbPartition = 2;
        List<Integer> alist = new ArrayList<>();
        alist.add(1);
        alist.add(2);
        alist.add(3);
        alist.add(4);
        alist.add(5);
        //------------------------------------------------------
        int n = 3;
        ArrayList<ArrayList<Integer>> sousList = new ArrayList<>(n);
        //----1
        ArrayList<Integer> a1 = new ArrayList<>();
        a1.add(1);
        a1.add(2);
        sousList.add(a1);
        //------2
        ArrayList<Integer> a2 = new ArrayList<>();
        a2.add(3);
        a2.add(4);
        sousList.add(a2);
        //------3
        ArrayList<Integer> a3 = new ArrayList<>();
        a3.add(5);
        sousList.add(a3);
        assertEquals(sousList, prt.partitionList(alist, nbPartition));

    }
}
