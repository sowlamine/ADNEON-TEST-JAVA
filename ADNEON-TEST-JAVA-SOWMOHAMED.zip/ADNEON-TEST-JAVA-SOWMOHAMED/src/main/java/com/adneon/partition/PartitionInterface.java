/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adneon.partition;

import java.util.List;

/**
 *
 * @author sow
 */
public interface PartitionInterface {
    public List partitionList(List listNombre, int taille) ;
}
