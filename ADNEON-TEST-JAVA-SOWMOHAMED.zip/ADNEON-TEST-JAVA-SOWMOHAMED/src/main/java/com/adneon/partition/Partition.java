/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adneon.partition;

/**
 *
 * @author sow
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.adneon.partition.PartitionService;
import org.apache.commons.collections4.ListUtils;

public class Partition {

    //--------------------------------------------------------------------
  

    //----------------------------------------------------------------------
    public static void main(String[] args) {
        int num = 0;
        int nbp = 0;
        List<Integer> alist = new ArrayList<Integer>();
        //Remplir le tableau
        Scanner sc = new Scanner(System.in);
        while (num != -1) {
            System.out.println("Bonjour veiller donnez les elements de la liste ,"
                    + " appuyez sur -1 pour finir les elements de la liste ");
            num = sc.nextInt();
            if (num != -1) {
                alist.add(num);
            }
        }
        if (num == -1) {
            System.out.println("Veiller donner la taille des partitions : ");
            Scanner tp = new Scanner(System.in);
            nbp = tp.nextInt();
            if (nbp != 0) {
                PartitionService prt = new PartitionService();
                System.out.println("Voici la liste partionnee en sous liste");
                prt.partitionList(alist, nbp);
            } else {
                System.out.println("Erreur nombre partition ......... ");
            }

        }
    }

}
