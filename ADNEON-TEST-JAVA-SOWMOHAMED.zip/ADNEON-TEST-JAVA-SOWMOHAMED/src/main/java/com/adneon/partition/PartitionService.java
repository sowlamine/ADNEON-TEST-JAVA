/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.adneon.partition;

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.List;
import org.apache.commons.collections4.ListUtils;

/**
 *
 * @author sow
 */
public class PartitionService implements PartitionInterface{
    //Partionne une liste
    public List partitionList(List listNombre, int taille) {
        List<List<Integer>> itr = ListUtils.partition(listNombre, taille);
        for (List<Integer> i : itr) {
            System.out.println("[" + i + ",]");
        }
        return itr;
    }
  
}
